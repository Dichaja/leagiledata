<?php
require_once('../xsert.php');
header('Content-Type: application/json');

// Fetch reports
$sql = "SELECT id, title, author, description, price, thumbnail, category, download_url FROM reports  ORDER BY created_at DESC LIMIT 10";
$result = $conn->prepare($sql);
$result->execute();
$reports = [];
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $reports[] = $row;
}

echo json_encode($reports); 
?>
