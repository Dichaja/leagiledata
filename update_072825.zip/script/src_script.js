/* Set up download button click handlers
document.addEventListener('DOMContentLoaded', function() {
  // Handle download button clicks
  document.querySelectorAll('button[data-id].download-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      // Create item from button data attributes
      const downloadItem = {
        id: this.dataset.id,
        title: this.dataset.title,
        price: parseFloat(this.dataset.price),
        category: this.dataset.category,
        thumbnail: this.dataset.thumbnail,
        download_url: this.dataset.downloadUrl,
        quantity: 1
      };
      
      // Save to localStorage as single-item cart
      localStorage.setItem('cart', JSON.stringify([downloadItem]));
      localStorage.setItem('directDownload', 'true');
      
      // Redirect to checkout page
      window.location.href = 'checkout.php';
    });
  });
});*/

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Set up download button click handlers using event delegation
  document.addEventListener('click', function(e) {
    // Check if clicked element or its parent is a download button
    const downloadBtn = e.target.closest('.download-btn');
    if (downloadBtn) {
      e.preventDefault();
      
      // Get all data from button attributes
      const item = {
        id: downloadBtn.dataset.id,
        title: downloadBtn.dataset.title,
        price: parseFloat(downloadBtn.dataset.price),
        category: downloadBtn.dataset.category,
        thumbnail: downloadBtn.dataset.thumbnail,
        download_url: downloadBtn.dataset.downloadUrl || '',
        quantity: 1
      };
      
      // Save as single-item cart
      localStorage.setItem('cart', JSON.stringify([item]));
      localStorage.setItem('directDownload', 'true');
      
      // Redirect to checkout
      window.location.href = 'checkout.php';
    }
  });
});