<?php
session_start();
require_once('bin/page_settings.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('bin/source_links.php'); ?>
</head>
<body>
 <!-- Header Section -->
 <?php siteHeader() ?>
<main class="flex-grow">
  <div class="container mx-auto px-4 py-8">
    <div class="container mx-auto px-4 py-8">
  <!-- Header -->
  <div class="flex items-center mb-6">
    <a href="cart.php">
      <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground h-9 p-0 mr-2">
        <svg class="lucide lucide-arrow-left h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
          <path d="m12 19-7-7 7-7"></path>
          <path d="M19 12H5"></path>
        </svg>
        Back to Shopping
      </button>
    </a>
    <h1 class="text-2xl font-bold">Checkout</h1>
  </div>

  <!-- Main grid layout -->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Cart Items Column -->
    <div class="lg:col-span-2">
      <div class="rounded-xl border bg-card text-card-foreground shadow" id="payment-method-container">
  <div class="flex flex-col space-y-1.5 p-6">
    <h3 class="font-semibold leading-none tracking-tight">Payment Method</h3>
    <p class="text-sm text-muted-foreground">Choose your preferred payment method</p>
  </div>
  <div class="p-6 pt-0">
    <div dir="ltr" data-orientation="horizontal" class="w-full">
      <!-- Tab List -->
      <div role="tablist" aria-orientation="horizontal" class="h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground grid grid-cols-3 mb-8" tabindex="0">
        <!-- Credit Card Tab -->
        <button type="button" role="tab" aria-selected="false" aria-controls="credit-card-content" data-state="inactive" class="tab-button inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow" data-target="credit-card-content">Credit Card</button>
        
        <!-- MTN Money Tab -->
        <button type="button" role="tab" aria-selected="false" aria-controls="mtn-money-content" data-state="inactive" class="tab-button inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow" data-target="mtn-money-content">MTN Money</button>
        
        <!-- Bank Transfer Tab -->
        <button type="button" role="tab" aria-selected="true" aria-controls="bank-transfer-content" data-state="active" class="tab-button inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow" data-target="bank-transfer-content">Bank Transfer</button>
      </div>

      <!-- Tab Panels -->
      <!-- Credit Card Content -->
      <div id="credit-card-content" data-state="inactive" role="tabpanel" class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 hidden">
        <form class="space-y-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-medium">Card Details</h3>
            <div class="flex gap-2">
              <div class="h-8 w-12 rounded border flex items-center justify-center bg-slate-50">
                <span class="text-xs font-bold text-blue-600">VISA</span>
              </div>
              <div class="h-8 w-12 rounded border flex items-center justify-center bg-slate-50">
                <span class="text-xs font-bold text-red-600">MC</span>
              </div>
            </div>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium leading-none">Card Number</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="1234 5678 9012 3456" name="cardNumber" maxlength="19">
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium leading-none">Cardholder Name</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="John Doe" name="cardholderName">
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div class="space-y-2">
              <label class="text-sm font-medium leading-none">Expiry Date</label>
              <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="MM/YY" name="expiryDate" maxlength="5">
            </div>
            <div class="space-y-2">
              <label class="text-sm font-medium leading-none">CVV</label>
              <input type="password" class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="123" name="cvv" maxlength="4">
            </div>
          </div>
          <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-9 px-4 py-2 w-full mt-6" type="submit">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card mr-2 h-4 w-4">
              <rect width="20" height="14" x="2" y="5" rx="2"></rect>
              <line x1="2" x2="22" y1="10" y2="10"></line>
            </svg>
            Pay $86.39
          </button>
        </form>
      </div>

      <!-- MTN Money Content -->
      <div id="mtn-money-content" data-state="inactive" role="tabpanel" class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 hidden">
        <form class="space-y-4">
          <div class="flex items-center mb-4">
            <div class="h-10 w-10 rounded-full bg-yellow-400 mr-3 flex items-center justify-center">
              <span class="font-bold text-black">MTN</span>
            </div>
            <h3 class="text-lg font-medium">MTN Money</h3>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium leading-none">MTN Phone Number</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="07XXXXXXXX" name="phoneNumber">
            <p class="text-[0.8rem] text-muted-foreground">Enter the MTN number registered with MTN Money</p>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium leading-none">Full Name</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="John Doe" name="fullName">
            <p class="text-[0.8rem] text-muted-foreground">Enter the name registered with MTN Money</p>
          </div>
          <div class="bg-yellow-50 p-4 rounded-md mt-4">
            <p class="text-sm">You will receive a prompt on your phone to confirm the payment of $86.39. Please enter your MTN Money PIN to complete the transaction.</p>
          </div>
          <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 text-primary-foreground shadow h-9 px-4 py-2 w-full mt-6 bg-yellow-500 hover:bg-yellow-600" type="submit">
            Pay with MTN Money: $86.39
          </button>
        </form>
      </div>

      <!-- Bank Transfer Content (active by default) -->
      <div id="bank-transfer-content" data-state="active" role="tabpanel" class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
        <div class="space-y-6">
          <div class="flex items-center mb-4">
            <div class="h-10 w-10 rounded-full bg-blue-500 mr-3 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-banknote text-white h-5 w-5">
                <rect width="20" height="12" x="2" y="6" rx="2"></rect>
                <circle cx="12" cy="12" r="2"></circle>
                <path d="M6 12h.01M18 12h.01"></path>
              </svg>
            </div>
            <h3 class="text-lg font-medium">Bank Transfer Details</h3>
          </div>

          <div class="bg-blue-50 p-4 rounded-md">
            <h4 class="font-medium mb-2">Please transfer the payment to:</h4>
            <div class="grid gap-3">
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Bank Name:</span>
                <span class="font-medium">Global Commerce Bank</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Name:</span>
                <span class="font-medium">Acme Corporation Ltd</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Number:</span>
                <span class="font-medium">1234567890</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">SWIFT/BIC:</span>
                <span class="font-medium">GCBLUS33</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Routing Number:</span>
                <span class="font-medium">026009593</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Amount:</span>
                <span class="font-medium">$86.39</span>
              </div>
            </div>
          </div>

          <div class="space-y-2">
            <label class="text-sm font-medium leading-none">Reference/Invoice Number</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Enter your invoice or reference number" name="referenceNumber">
            <p class="text-[0.8rem] text-muted-foreground">Please include this reference with your transfer</p>
          </div>

          <div class="bg-blue-50 p-4 rounded-md">
            <h4 class="font-medium mb-2">Important Instructions:</h4>
            <ul class="text-sm space-y-2 list-disc pl-5">
              <li>Transfers typically take 1-3 business days to process</li>
              <li>Your order will be processed after we receive the payment</li>
              <li>Please email your transfer receipt to payments@example.com</li>
              <li>Include your order number in the payment reference</li>
            </ul>
          </div>

          <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white shadow hover:bg-blue-700 h-9 px-4 py-2 w-full mt-6" type="button">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-printer mr-2 h-4 w-4">
              <polyline points="6 9 6 2 18 2 18 9"></polyline>
              <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
              <rect width="12" height="8" x="6" y="14"></rect>
            </svg>
            Print Bank Details
          </button>
        </div>
      </div>
    </div>
  </div>
    </div>
    </div>
    <!-- Order Summary -->
    <div>
      <div class="rounded-xl border bg-card text-card-foreground shadow">
        <div class="flex flex-col space-y-1.5 p-6">
          <h3 class="font-semibold leading-none tracking-tight">Order Summary</h3>
        </div>
        <div id="order-summary" class="p-6 pt-0"></div>
        <div class="flex items-center p-6 pt-0">
          <button class="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-10 rounded-md px-8 w-full">
            <svg class="lucide lucide-credit-card mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <rect width="20" height="14" x="2" y="5" rx="2"></rect>
              <line x1="2" x2="22" y1="10" y2="10"></line>
            </svg>
            Proceed to Checkout
          </button>
        </div>
      </div>
      </div>
      <!-- Terms -->
      <div class="mt-4 text-sm text-muted-foreground">
        <p class="mb-2">
          By proceeding to checkout, you agree to our 
          <a class="underline hover:text-primary" href="/terms">Terms of Service</a>.
        </p>
        <p>
          Need help? Contact our 
          <a class="underline hover:text-primary" href="/support">customer support</a>.
        </p>
      </div>
    </div>
  </div>
</div>

  </div>
</main>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('[role="tabpanel"]');
    
    // Initialize with Bank Transfer as active
    const defaultTab = document.querySelector('[data-target="bank-transfer-content"]');
    activateTab(defaultTab);
    
    // Add click event to all tab buttons
    tabButtons.forEach(button => {
      button.addEventListener('click', function() {
        activateTab(this);
      });
    });
    
    function activateTab(activeButton) {
      // Deactivate all tabs
      tabButtons.forEach(button => {
        button.setAttribute('aria-selected', 'false');
        button.setAttribute('data-state', 'inactive');
      });
      
      // Hide all panels
      tabPanels.forEach(panel => {
        panel.setAttribute('data-state', 'inactive');
        panel.classList.add('hidden');
      });
      
      // Activate clicked tab
      activeButton.setAttribute('aria-selected', 'true');
      activeButton.setAttribute('data-state', 'active');
      
      // Show corresponding panel
      const targetPanel = document.getElementById(activeButton.getAttribute('data-target'));
      targetPanel.setAttribute('data-state', 'active');
      targetPanel.classList.remove('hidden');
    }

  renderCartItem();

  });

  function renderCartItems() {
      
      const summaryContainer = document.getElementById("order-summary");

      if (!summaryContainer) return;

      const cart = JSON.parse(localStorage.getItem("cart")) || [];
      let subtotal = 0;
         cart.forEach(item => {
            subtotal += item.price;
         });

      const tax = subtotal * 0.08;
      const total = subtotal + tax;

      summaryContainer.innerHTML = `
        <div class="flex justify-between"><span class="text-muted-foreground">Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
        <!--<div class="flex justify-between"><span class="text-muted-foreground">Tax (8%)</span><span>$${tax.toFixed(2)}</span></div>-->
        <div class="shrink-0 bg-border h-[1px] w-full my-2"></div>
        <div class="flex justify-between font-medium text-lg"><span>Total</span><span>$${subtotal.toFixed(2)}</span></div>
      `;
    }


function renderCartItem() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const summaryContainer = document.getElementById('order-summary');
  
  if (summaryContainer) {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    
    summaryContainer.innerHTML = `
        <div class="flex justify-between"><span class="text-muted-foreground">Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
        <div class="flex justify-between"><span class="text-muted-foreground">Tax (8%)</span><span>$${tax.toFixed(2)}</span></div>
        <div class="shrink-0 bg-border h-[1px] w-full my-2"></div>
        <div class="flex justify-between font-medium text-lg"><span>Total</span><span>$${total.toFixed(2)}</span></div>
      `;
      console.log(cart)
  }
}

function handleDirectDownload() {
  if (localStorage.getItem('directDownload') === 'true') {
    // Optional: Highlight download section or auto-scroll
    const downloadSection = document.getElementById('download-section');
    if (downloadSection) {
      downloadSection.scrollIntoView({ behavior: 'smooth' });
      downloadSection.classList.add('ring-2', 'ring-blue-500', 'rounded-lg');
    }
    
    // Clear the flag
    localStorage.removeItem('directDownload');
  }
}

</script>

<!-- footer section -->
<?php siteFooter() ?>
</body>
</html>