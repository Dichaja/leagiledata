<?php
session_start();
require_once('bin/page_settings.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leagile Data Research Center</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="tail.css">
    <link rel="icon" type="image/png" href="img_data/logo_fav.png" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@next/dist/aos.css" rel="stylesheet">
    <link  rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
 <!-- Header Section -->
 <?php siteHeader() ?>
<main class="flex-grow">
  <div class="container mx-auto px-4 py-8">
    <div class="container mx-auto px-4 py-8">
  <!-- Header -->
  <div class="flex items-center mb-6">
    <a href="/">
      <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground h-9 p-0 mr-2">
        <svg class="lucide lucide-arrow-left h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
          <path d="m12 19-7-7 7-7"></path>
          <path d="M19 12H5"></path>
        </svg>
        Continue Shopping
      </button>
    </a>
    <h1 class="text-2xl font-bold">Your Cart</h1>
  </div>

  <!-- Main grid layout -->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Cart Items Column -->
    <div class="lg:col-span-2">
      <div class="rounded-xl border bg-card text-card-foreground shadow">
        <div class="flex flex-col space-y-1.5 p-6">
          <h3 class="font-semibold leading-none tracking-tight flex items-center">
            <svg class="lucide lucide-shopping-cart mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <circle cx="8" cy="21" r="1"></circle>
              <circle cx="19" cy="21" r="1"></circle>
              <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
            </svg>
            Cart Items (1)
          </h3>
        </div>

        <!-- Cart Item -->
        <!-- Cart Item Container -->
<div id="cart-item" class="p-6 pt-0">
  <!-- JS will inject items here -->
</div>

    </div>

    <!-- Order Summary -->
    <div>
      <div class="rounded-xl border bg-card text-card-foreground shadow">
        <div class="flex flex-col space-y-1.5 p-6">
          <h3 class="font-semibold leading-none tracking-tight">Order Summary</h3>
        </div>
        <div class="p-6 pt-0">
          <div class="space-y-2">
           <div class="flex justify-between">
                 <span class="text-muted-foreground">Subtotal</span>
                 <span class="cart-subtotal">$0.00</span>
          </div>
          <div class="flex justify-between">
               <span class="text-muted-foreground">Tax (8%)</span>
               <span class="cart-tax">$0.00</span>
           </div>...
           <div class="flex justify-between font-medium text-lg">
               <span>Total</span>
               <span class="cart-total">$0.00</span>
           </div>
        </div>
      </div>
        <div class="flex items-center p-6 pt-0">
          <button class="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-10 rounded-md px-8 w-full">
            <svg class="lucide lucide-credit-card mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
              <rect width="20" height="14" x="2" y="5" rx="2"></rect>
              <line x1="2" x2="22" y1="10" y2="10"></line>
            </svg>
            Proceed to Checkout
          </button>
        </div>
      </div>

      <!-- Terms -->
      <div class="mt-4 text-sm text-muted-foreground">
        <p class="mb-2">
          By proceeding to checkout, you agree to our 
          <a class="underline hover:text-primary" href="/terms">Terms of Service</a>.
        </p>
        <p>
          Need help? Contact our 
          <a class="underline hover:text-primary" href="/support">customer support</a>.
        </p>
      </div>
    </div>
  </div>
</div>

  </div>
</main>
<!-- footer section -->
<?php siteFooter() ?>
</body>
</html>