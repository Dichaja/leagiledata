<?php
session_start();
require_once('bin/page_settings.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leagile Data Research Center</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="tail.css">
    <link rel="icon" type="image/png" href="img_data/logo_fav.png" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@next/dist/aos.css" rel="stylesheet">
    <link  rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

</head>
<body>
 <!-- Header Section -->
 <?php siteHeader() ?>
<main class="flex-grow">
  <div class="container mx-auto px-4 py-8">
    
    <!-- Header + Button + Search -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
      
      <!-- Title and Add File Button -->
      <div>
        <h1 class="text-3xl font-bold mb-2">Research Categories</h1>
        <p class="text-muted-foreground">
          Browse our comprehensive collection of research reports by category
        </p>
        <div class="mt-4">
          <a href="/add-report">
            <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 text-primary-foreground shadow h-9 px-4 py-2 bg-primary hover:bg-primary/90">
              Add New File
            </button>
          </a>
        </div>
      </div>

      <!-- Search Bar -->
      <div class="relative w-full md:w-64">
        <svg class="lucide lucide-search absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400"
             xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <path d="m21 21-4.3-4.3"></path>
        </svg>
        <input class="flex h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 pl-9 w-full"
               placeholder="Search categories..." value="">
      </div>

    </div>

    <!-- Grid of Research Categories -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <!-- START OF CATEGORY CARDS -->

      <!-- Example Card Start -->
      <a href="/categories/academic">
        <div class="rounded-xl border bg-card text-card-foreground shadow h-full transition-all duration-200 hover:shadow-md hover:border-primary/50">
          <div class="flex flex-col items-center text-center p-6">
            <div class="text-primary p-3 rounded-full bg-primary/10 mb-4">
              <!-- Academic Icon -->
              <svg class="lucide lucide-book-open" xmlns="http://www.w3.org/2000/svg"
                   width="24" height="24" fill="none" stroke="currentColor"
                   stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
              </svg>
            </div>
            <h3 class="font-semibold text-lg mb-2">Academic Research</h3>
            <p class="text-sm text-muted-foreground mb-3">
              Scholarly articles and papers from academic institutions
            </p>
            <span class="text-xs font-medium bg-secondary px-2 py-1 rounded-full">42 reports</span>
          </div>
        </div>
      </a>
      <!-- Example Card End -->

      <!-- Repeat above card block for other categories (Market Analysis, Scientific Studies, etc.) -->
      <!-- ... All category cards remain unchanged but properly indented -->

      <!-- Your remaining 9 cards go here... -->
      <!-- Paste them directly below, following the same structure -->

    </div>
  </div>
</main>

<footer class="bg-slate-900 text-white py-12 w-full">
  <div class="max-w-7xl mx-auto px-4">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-10 text-left">

      <!-- Logo and Description -->
      <div>
        <div class="flex items-center gap-3 mb-4">
          <img src="/logo.png" alt="Leagile Logo" class="h-10 w-auto bg-white rounded p-1">
          <h3 class="text-xl font-bold leading-tight">Leagile Data <br> Research Center</h3>
        </div>
        <p class="text-slate-300 mb-4">
          Your trusted platform for expert research and consultation services.
        </p>
        <div class="flex space-x-4 text-slate-300">
          <a href="#" class="hover:text-white"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="hover:text-white"><i class="fab fa-twitter"></i></a>
          <a href="#" class="hover:text-white"><i class="fab fa-linkedin-in"></i></a>
          <a href="#" class="hover:text-white"><i class="fab fa-instagram"></i></a>
          <a href="#" class="hover:text-white"><i class="fab fa-github"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div>
        <h3 class="text-lg font-semibold mb-4">Quick Links</h3>
        <ul class="space-y-2 text-slate-300">
          <li><a href="#" class="hover:text-white">Home</a></li>
          <li><a href="#" class="hover:text-white">Browse Reports</a></li>
          <li><a href="#" class="hover:text-white">Subscription Plans</a></li>
          <li><a href="#" class="hover:text-white">Expert Directory</a></li>
          <li><a href="#" class="hover:text-white">About Us</a></li>
        </ul>
      </div>

      <!-- Research Categories -->
      <div>
        <h3 class="text-lg font-semibold mb-4">Research Categories</h3>
        <ul class="space-y-2 text-slate-300">
          <li><a href="#" class="hover:text-white">Business & Finance</a></li>
          <li><a href="#" class="hover:text-white">Technology & Innovation</a></li>
          <li><a href="#" class="hover:text-white">Healthcare & Medicine</a></li>
          <li><a href="#" class="hover:text-white">Environmental Studies</a></li>
          <li><a href="#" class="hover:text-white">Social Sciences</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div>
        <h3 class="text-lg font-semibold mb-4">Contact Us</h3>
        <ul class="space-y-3 text-slate-300">
          <li class="flex items-start gap-2">
            <i class="fas fa-map-marker-alt text-slate-400 mt-1"></i>
            <span>123 Research Avenue, Knowledge City, 10001</span>
          </li>
          <li class="flex items-center gap-2">
            <i class="fas fa-phone text-slate-400"></i>
            <span>+1 (555) 123-4567</span>
          </li>
          <li class="flex items-center gap-2">
            <i class="fas fa-envelope text-slate-400"></i>
            <span>contact@researchmarket.com</span>
          </li>
        </ul>
      </div>
    </div>

    <!-- Divider -->
    <div class="my-8 h-px bg-slate-700 w-full"></div>

    <!-- Bottom Bar -->
    <div class="text-sm text-slate-400">
      <p>&copy; 2025 Leagile Data Research Center. All rights reserved.</p>
      <div class="mt-2">
        <a href="#" class="hover:text-white">Privacy Policy</a>
        <span class="mx-2">|</span>
        <a href="#" class="hover:text-white">Terms of Service</a>
      </div>
    </div>
  </div>
</footer>
</body>
</html>