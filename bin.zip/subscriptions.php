<?php
session_start();
require_once('bin/page_settings.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leagile Data Research Center</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="tail.css">
    <link rel="icon" type="image/png" href="img_data/logo_fav.png" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@next/dist/aos.css" rel="stylesheet">
    <link  rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
 <!-- Header Section -->
 <?php siteHeader() ?>
<main class="flex-grow">
  <div class="container mx-auto px-4 py-8">
    <div class="text-center mb-12">
         <h1 class="text-4xl font-bold tracking-tight mb-3">
              Research Subscription Plans
         </h1>
         <p class="text-xl text-muted-foreground max-w-2xl mx-auto">
             Get unlimited access to expert research reports and consultations with our flexible subscription options
         </p>
    </div>
    <div dir="ltr" data-orientation="horizontal" class="w-full">
  <!-- Tab Navigation -->
  <div class="flex justify-center mb-8">
    <div role="tablist" aria-orientation="horizontal" class="inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground" tabindex="0" style="outline: none;">
      <button type="button" role="tab" aria-selected="true" aria-controls="radix-:r52:-content-monthly" id="radix-:r52:-trigger-monthly"
        class="inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50
        data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow"
        data-state="active">
        Monthly Billing
      </button>
      <button type="button" role="tab" aria-selected="false" aria-controls="radix-:r52:-content-annual" id="radix-:r52:-trigger-annual"
        class="inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50
        data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow"
        data-state="inactive">
        Annual Billing (Save 20%)
      </button>
    </div>
  </div>

  <!-- Monthly Tab Content -->
  <div data-state="active" role="tabpanel" aria-labelledby="radix-:r52:-trigger-monthly" id="radix-:r52:-content-monthly" tabindex="0"
    class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">

    <div class="bg-gray-50 py-12">
      <div class="container mx-auto px-4">

        <!-- Header -->
        <div class="text-center mb-12">
          <h2 class="text-3xl font-bold tracking-tight mb-2">Subscription Plans</h2>
          <p class="text-gray-600 max-w-2xl mx-auto">
            Choose the perfect plan to access premium research reports and expert consultations
          </p>
        </div>

        <!-- Plan Grid -->
        <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">

          <!-- Basic Plan -->
          <div class="rounded-xl border bg-card text-card-foreground shadow relative border-gray-200">
            <div class="flex flex-col space-y-1.5 p-6">
              <h3 class="font-semibold tracking-tight text-2xl">Basic</h3>
              <p class="text-sm text-muted-foreground">Essential access to research reports</p>
            </div>
            <div class="p-6 pt-0">
              <div class="mb-6">
                <span class="text-4xl font-bold">$9.99</span>
                <span class="text-gray-500 ml-2">per month</span>
              </div>
              <ul class="space-y-3">
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Access to basic research reports</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Monthly newsletter</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Community forum access</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Basic search functionality</li>
              </ul>
            </div>
            <div class="flex items-center p-6 pt-0">
              <button class="w-full h-9 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-md shadow text-sm font-medium">
                Get Started
              </button>
            </div>
          </div>

          <!-- Premium Plan -->
          <div class="rounded-xl border bg-card text-card-foreground relative border-primary shadow-lg">
            <div class="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
              <span class="bg-primary text-white text-xs font-semibold px-3 py-1 rounded-full">Most Popular</span>
            </div>
            <div class="flex flex-col space-y-1.5 p-6">
              <h3 class="font-semibold tracking-tight text-2xl">Premium</h3>
              <p class="text-sm text-muted-foreground">Full access with expert consultation</p>
            </div>
            <div class="p-6 pt-0">
              <div class="mb-6">
                <span class="text-4xl font-bold">$29.99</span>
                <span class="text-gray-500 ml-2">per month</span>
              </div>
              <ul class="space-y-3">
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Access to your research reports</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Downloads at discounted price</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Contacting experts</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Priority email & phone support</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Notification on latest research works</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Advanced filtering and search</li>
                <li class="flex items-start"><i class="lucide lucide-check text-green-500 mr-2 h-5 w-5"></i> Personalized recommendations</li>
              </ul>
            </div>
            <div class="flex items-center p-6 pt-0">
              <button class="w-full h-9 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-md shadow text-sm font-medium">
                Upgrade Now
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Annual Tab Content (Hidden) -->
  <div data-state="inactive" role="tabpanel" aria-labelledby="radix-:r52:-trigger-annual" hidden id="radix-:r52:-content-annual" tabindex="0"
    class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
  </div>
</div>
<section class="mb-16">
  <h2 class="text-2xl font-bold text-center mb-8">What Our Subscribers Say</h2>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    
    <!-- Emily (Annual Premium) -->
    <div class="bg-white p-6 rounded-lg shadow-sm border">
      <div class="flex items-center mb-4">
        <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=testimonial3" alt="User avatar" class="w-12 h-12 rounded-full">
        <div class="ml-4">
          <h4 class="font-semibold">Emily Rodriguez</h4>
          <p class="text-sm text-muted-foreground">Academic Researcher</p>
        </div>
      </div>
      <blockquote class="text-muted-foreground">
        "The annual Premium subscription offers incredible value. The unlimited access to reports and expert consultations has significantly accelerated my research projects."
      </blockquote>
    </div>

    <!-- Sarah (Premium Monthly) -->
    <div class="bg-white p-6 rounded-lg shadow-sm border">
      <div class="flex items-center mb-4">
        <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=testimonial1" alt="User avatar" class="w-12 h-12 rounded-full">
        <div class="ml-4">
          <h4 class="font-semibold">Sarah Johnson</h4>
          <p class="text-sm text-muted-foreground">Marketing Director</p>
        </div>
      </div>
      <blockquote class="text-muted-foreground">
        "The Premium subscription has been invaluable for our market research. The expert consultations alone are worth the price, providing insights we couldn't get elsewhere."
      </blockquote>
    </div>

    <!-- Michael (Free Subscriber) -->
    <div class="bg-white p-6 rounded-lg shadow-sm border">
      <div class="flex items-center mb-4">
        <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=testimonial2" alt="User avatar" class="w-12 h-12 rounded-full">
        <div class="ml-4">
          <h4 class="font-semibold">Michael Chen</h4>
          <p class="text-sm text-muted-foreground">Investment Analyst</p>
        </div>
      </div>
      <blockquote class="text-muted-foreground">
        "I've been a Free subscriber for six months, and the quality of research reports is exceptional. It's helped me make more informed investment decisions."
      </blockquote>
    </div>

  </div>
</section>

  </div>
</main>
<!-- footer section -->
<?php siteFooter() ?>
</body>
</html>