//new
async function fetchReports() {
  try {
    const response = await fetch('fetch/get_reports.php');

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const reports = await response.json();

    console.log("Fetched Reports:", reports);

    // Now render or process the reports
    const container = document.getElementById('report-carousel');

    container.innerHTML = ''; // Clear existing

    reports.forEach(report => {
      const card = document.createElement('div');
      card.className = 'transition-all duration-300 ease-in-out min-w-[250px] max-w-[350px] flex-shrink-0';

      card.innerHTML = `
        <div class="rounded-xl border shadow w-full h-[380px] flex flex-col overflow-hidden bg-white text-card-foreground">
          <div class="relative h-40 overflow-hidden">
            <img src="${report.thumbnail}" alt="${report.title}" class="w-full h-full object-cover transition-transform hover:scale-105">
            <div class="absolute top-2 right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded">${report.category}</div>
          </div>
          <div class="flex flex-col space-y-1.5 p-4 pb-0">
            <h3 class="tracking-tight text-lg font-bold line-clamp-1">${report.title}</h3>
            <p class="text-sm text-gray-600 mt-1">${report.author}</p>
          </div>
          <div class="p-4 flex-grow">
            <p class="text-muted-foreground text-sm line-clamp-3">${report.description}</p>
            <div class="mt-2 flex items-center gap-1">
              ${renderStars(report.rating)}
              <span class="ml-1 text-sm text-gray-600">${report.rating}</span>
            </div>
          </div>
          <div class="p-4 pt-0 flex justify-between items-center">
            <div class="font-bold text-lg">$${report.price}</div>
            <!--<div class="flex gap-2">
              <a href="${report.download_url}" class="flex items-center gap-1 text-xs px-3 h-8 rounded-md border bg-background shadow-sm hover:bg-accent hover:text-accent-foreground">
                <svg class="lucide lucide-download h-4 w-4" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2..."/></svg>Download
              </a>
              <button class="add-to-cart flex items-center gap-1 text-xs px-3 h-8 rounded-md bg-primary text-white shadow hover:bg-primary/90" data-id="${report.id}"  data-title="${report.title}" data-price="${report.price}" data-category="${report.category}" data-thumbnail="${report.thumbnail}">
                <svg class="lucide lucide-shopping-cart h-4 w-4" viewBox="0 0 24 24"><path d="M6 6h15l-1.5 9h-13L4 4H2"/></svg>Add
              </button>
            </div>-->
            <div class="flex gap-2">
  <button
    class="justify-center whitespace-nowrap font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground h-8 rounded-md px-3 text-xs flex items-center gap-1"
  >
    <a href="${report.download_url}" class="flex items-center gap-1 text-xs px-3 h-8 rounded-md border bg-background shadow-sm hover:bg-accent hover:text-accent-foreground"><svg xmlns="http://www.w3.org/2000/svg" width="24"
      height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"  stroke-linejoin="round" class="lucide lucide-download h-4 w-4">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" x2="12" y1="15" y2="3"></line>
    </svg>
    Download</a>
  </button>

  <button  class="justify-center whitespace-nowrap font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-8 rounded-md px-3 text-xs flex items-center gap-1"> 
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      class="lucide lucide-shopping-cart h-4 w-4"
    >
      <circle cx="8" cy="21" r="1"></circle>
      <circle cx="19" cy="21" r="1"></circle>
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
    </svg>
    Add
  </button>
</div>

          </div>
        </div>
      `;

      container.appendChild(card);
    });

  } catch (error) {
    console.error("Error fetching reports:", error);
  }
}

function renderStars(rating) {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  const stars = [];

  for (let i = 0; i < fullStars; i++) {
    stars.push(`<svg class="lucide lucide-star h-4 w-4 fill-yellow-400 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`);
  }

  if (halfStar) {
    stars.push(`
      <div class="relative">
        <svg class="lucide lucide-star h-4 w-4 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        <div class="absolute inset-0 overflow-hidden w-1/2">
          <svg class="lucide lucide-star h-4 w-4 fill-yellow-400 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        </div>
      </div>
    `);
  }

  return stars.join('');
}

// Call the function when the DOM is ready
document.addEventListener('DOMContentLoaded', fetchReports);