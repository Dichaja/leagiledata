<?php
require_once('../xsert.php');
header('Content-Type: application/json');

// Fetch reports
$sql = "SELECT id, title, author, description, price, rating, thumbnail, category, download_url FROM reports  ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);

$reports = [];
while ($row = $result->fetch_assoc()) {
    $reports[] = $row;
}

echo json_encode($reports);

$conn->close();
?>
