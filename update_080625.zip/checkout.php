<?php
session_start();
require_once('bin/page_settings.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('bin/source_links.php'); ?>
</head>
<body>
 <!-- Header Section -->
 <?php siteHeader() ?>
<main class="flex-grow">
  <div class="container mx-auto px-4 py-8">
    <div class="container mx-auto px-4 py-8">
  <!-- Header -->
  <div class="flex items-center mb-6">
    <a href="cart.php">
      <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground h-9 p-0 mr-2">
        <svg class="lucide lucide-arrow-left h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
          <path d="m12 19-7-7 7-7"></path>
          <path d="M19 12H5"></path>
        </svg>
        Back to Shopping
      </button>
    </a>
    <h1 class="text-2xl font-bold">Checkout</h1>
  </div>

  <!-- Main grid layout -->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Cart Items Column -->
    <div class="lg:col-span-2">
      <div class="rounded-xl border bg-card text-card-foreground shadow" id="payment-method-container">
  <div class="flex flex-col space-y-1.5 p-6">
    <h3 class="font-semibold leading-none tracking-tight">Payment Method</h3>
    <p class="text-sm text-muted-foreground">Choose your preferred payment method</p>
  </div>
  <div class="p-6 pt-0">
    <div dir="ltr" data-orientation="horizontal" class="w-full">
      <!-- Tab List -->
      <div role="tablist" aria-orientation="horizontal" class="h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground grid grid-cols-2 mb-8" tabindex="0">        
        <!-- MTN Money Tab -->
        <button type="button" role="tab" aria-selected="false" aria-controls="mtn-money-content" data-state="inactive" class="tab-button inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow" data-target="mtn-money-content">Mobile Money</button>
        
        <!-- Bank Transfer Tab -->
        <button type="button" role="tab" aria-selected="true" aria-controls="bank-transfer-content" data-state="active" class="tab-button inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow" data-target="bank-transfer-content">Bank Transfer</button>
      </div>
      <!-- MTN Money Content -->
      <div id="mtn-money-content" data-state="inactive" role="tabpanel" class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 hidden">
          <div class="space-y-2">
            <div class="bg-blue-50 p-4 rounded-md">
            <h4 class="font-medium mb-2">Send Payment Mobile Account:</h4>
            <div class="grid gap-3">
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Name:</span>
                <span class="font-medium">Mbago Musa</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Operator:</span>
                <span class="font-medium">Airtel Ug</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Number:</span>
                <span class="font-medium">(+256)701 339 667</span>
              </div>
          </div></div></div>
      </div>

      <!-- Bank Transfer Content (active by default) -->
      <div id="bank-transfer-content" data-state="active" role="tabpanel" class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
        <div class="space-y-6">
          <div class="flex items-center mb-4">
            <div class="h-10 w-10 rounded-full bg-blue-500 mr-3 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-banknote text-white h-5 w-5">
                <rect width="20" height="12" x="2" y="6" rx="2"></rect>
                <circle cx="12" cy="12" r="2"></circle>
                <path d="M6 12h.01M18 12h.01"></path>
              </svg>
            </div>
            <h3 class="text-lg font-medium">Bank Transfer Details</h3>
          </div>

          <div class="bg-blue-50 p-4 rounded-md">
            <h4 class="font-medium mb-2">Please transfer the payment to:</h4>
            <div class="grid gap-3">
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Bank Name:</span>
                <span class="font-medium">KCB - Kenya Commercial Bank</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Name:</span>
                <span class="font-medium">Leagile Research</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">Account Number:</span>
                <span class="font-medium">2329505574</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-muted-foreground">SWIFT/BIC:</span>
                <span class="font-medium">KCBLUKAXXX</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="space-y-2">
            <label class="text-sm font-medium leading-none">Reference/Invoice Number</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" placeholder="Enter your invoice or reference number" name="referenceNumber">
            <p class="text-[0.8rem] text-muted-foreground">Please include this reference with your transfer</p>
          </div>

          <div class="bg-blue-50 p-4 rounded-md">
            <h4 class="font-medium mb-2">Important Instructions:</h4>
            <ul class="text-sm space-y-2 list-disc pl-5">
              <li>Your Download Link will be Sent to Your After We Receive The Payment</li>
              <li>Please email your transfer receipt to payments@example.com</li>
              <li>Include Your Reference/Invoice Number in the Payment Reference</li>
            </ul>
          </div>
    </div>
  </div>
    </div>
    </div>
    <!-- Order Summary -->
    <div>
      <div class="rounded-xl border bg-card text-card-foreground shadow">
        <div class="flex flex-col space-y-1.5 p-6">
          <h3 class="font-semibold leading-none tracking-tight">Order Summary</h3>
        </div>
        <div id="order-summary" class="p-6 pt-0"></div>
      </div>
      </div>
      <!-- Terms -->
      <div class="mt-4 text-sm text-muted-foreground">
        <p class="mb-2">
          By proceeding to checkout, you agree to our 
          <a class="underline hover:text-primary" href="/terms">Terms of Service</a>.
        </p>
        <p>
          Need help? Contact our 
          <a class="underline hover:text-primary" href="/support">customer support</a>.
        </p>
      </div>
    </div>
  </div>
</div>

  </div>
</main>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('[role="tabpanel"]');
    
    // Initialize with Bank Transfer as active
    const defaultTab = document.querySelector('[data-target="bank-transfer-content"]');
    activateTab(defaultTab);
    
    // Add click event to all tab buttons
    tabButtons.forEach(button => {
      button.addEventListener('click', function() {
        activateTab(this);
      });
    });
    
    function activateTab(activeButton) {
      // Deactivate all tabs
      tabButtons.forEach(button => {
        button.setAttribute('aria-selected', 'false');
        button.setAttribute('data-state', 'inactive');
      });
      
      // Hide all panels
      tabPanels.forEach(panel => {
        panel.setAttribute('data-state', 'inactive');
        panel.classList.add('hidden');
      });
      
      // Activate clicked tab
      activeButton.setAttribute('aria-selected', 'true');
      activeButton.setAttribute('data-state', 'active');
      
      // Show corresponding panel
      const targetPanel = document.getElementById(activeButton.getAttribute('data-target'));
      targetPanel.setAttribute('data-state', 'active');
      targetPanel.classList.remove('hidden');
    }

  renderCartItem();

  });

 
function renderCartItem() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const summaryContainer = document.getElementById('order-summary');
  
  if (summaryContainer) {
    const subtotal = cart.reduce((sum, item) => sum + (item.price), 0);
    //const tax = subtotal * 0.08;
    const total = subtotal;
    
    // Format numbers with commas for thousands and 2 decimal places
    const formatCurrency = (num) => {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    };
    
    summaryContainer.innerHTML = `
      <div class="space-y-1">
        <div class="flex justify-between">
          <span class="text-muted-foreground">Subtotal</span>
          <span>$${formatCurrency(subtotal)}</span>
        </div>        
        <!-- Separator -->
        <div class="shrink-0 bg-border h-[1px] w-full my-2"></div>
        
        <div class="flex justify-between font-medium text-lg">
          <span>Total</span>
          <span>$${formatCurrency(total)}</span>
        </div>
      </div>
    `;
    console.log(cart);
  }
}

function handleDirectDownload() {
  if (localStorage.getItem('directDownload') === 'true') {
    // Optional: Highlight download section or auto-scroll
    const downloadSection = document.getElementById('download-section');
    if (downloadSection) {
      downloadSection.scrollIntoView({ behavior: 'smooth' });
      downloadSection.classList.add('ring-2', 'ring-blue-500', 'rounded-lg');
    }
    
    // Clear the flag
    localStorage.removeItem('directDownload');
  }
}

</script>
</body>
</html>