//new
async function fetchReports() {
  try {
    const response = await fetch('fetch/get_reports.php');

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const reports = await response.json();
    console.log(reports);

    
    const container = document.getElementById('report-cards');

    container.innerHTML = ''; // Clear existing

    reports.forEach(report => {
      const card = document.createElement('div');
      card.className = 'transition-all duration-300 ease-in-out min-w-[250px] max-w-[350px] flex-shrink-0 cursor-pointer';

      // Make the entire card clickable
      card.addEventListener('click', (e) => {
        // Don't navigate if clicking on buttons
        if (e.target.closest('.download-btn') || e.target.closest('.add-to-cart')) {
          return;
        }
        navigateToDetails(report);
      });

      if (report.thumbnail) {
            var imgSrc =  report.thumbnail;
        } else {
           var imgSrc = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23e5e7eb'%3E%3Cpath d='M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z'/%3E%3Cpath d='M14 17H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z'/%3E%3C/svg%3E";
        }

      card.innerHTML = `<!-- Report Card Template -->
<div class="bg-white p-3 sm:p-4 rounded-lg shadow-sm hover:shadow-md border border-gray-200 transition-all duration-200 hover:border-blue-200 hover:cursor-pointer">
    <!-- Image Container -->
    <div class="relative mb-2 sm:mb-3">
        <img src="${imgSrc}" alt="${report.title}" class="w-full h-32 sm:h-40 object-contain bg-gray-50 p-2">
    </div>
    
    <!-- Price -->
    <div class="mb-1 sm:mb-2 flex items-center">
        <span class="text-sm font-bold text-gray-900">$${report.price}</span>
    </div>
    
    <!-- Title -->
    <h3 class="text-xs sm:text-sm font-medium line-clamp-2 mb-1 sm:mb-2 min-h-[2.5em]">
        ${report.title}
    </h3>
    
    <!-- Stats -->
    <div class="flex items-center justify-between text-xs text-gray-500 mb-2 sm:mb-3">
        <div class="flex items-center">
            <!--<svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-yellow-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            <span>4.8</span>
            <span class="ml-1">(128)</span>-->
        </div>
        <span>${report.download_count ? report.download_count.toLocaleString() : '0'} downloads</span>
    </div>
    
    <!-- Action Buttons -->
    <div class="flex gap-2">
        <!-- Download Button -->
        <button class="download-btn flex-1 flex items-center justify-center gap-1 border border-gray-300 hover:bg-gray-50 text-gray-800 py-1.5 px-2 sm:px-3 rounded-md text-xs sm:text-sm transition-colors" data-id="${report.id}" data-title="${report.title}" data-price="${report.price}" data-category="${report.category}" data-thumbnail="${report.thumbnail}">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" x2="12" y1="15" y2="3"></line>
            </svg>
            Download
        </button>
        
        <!-- Add to Cart Button -->
        <button class="flex-1 flex items-center justify-center gap-1 bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-2 sm:px-3 rounded-md text-xs sm:text-sm transition-colors add-to-cart" data-id="${report.id}" data-title="${report.title}" data-price="${report.price}" data-category="${report.category}" data-thumbnail="${report.thumbnail}">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="8" cy="21" r="1"></circle>
                <circle cx="19" cy="21" r="1"></circle>
                <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
            </svg>
            Add
        </button>
    </div>
</div> `;
      container.appendChild(card);
    }); 
   
// Add event listeners to buttons
document.querySelectorAll('.download-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        //handleDownload(btn.dataset.id);
      });
});

document.querySelectorAll('.add-to-cart').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        //handleAddToCart(btn.dataset.id);
      });
    });

document.querySelectorAll(".add-to-cart").forEach(btn => {
    btn.addEventListener("click", () => {
        const item = {
            id: btn.dataset.id,  // Unique identifier for the product
            title: btn.dataset.title,
            price: parseFloat(btn.dataset.price),
            thumbnail: btn.dataset.thumbnail,
            category: btn.dataset.category
        };

        let cart = JSON.parse(localStorage.getItem("cart") || "[]");
        
        // Check if item already exists in cart
        const itemExists = cart.some(cartItem => cartItem.id === item.id);
        
        if (!itemExists) {
            cart.push(item);  
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartCount();              
            alert("Added to cart!");
        } else {
            alert("This item is already in your cart!");
        }
        syncCartItemWithServer(item, 'add')
    });
});

  } catch (error) {
    console.error("Error fetching reports:", error);
    document.getElementById('report-cards').innerHTML = '<p class="text-red-500">Error loading reports. Please try again later.</p>';
  }
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem("cart") || []);
  const cartCounts = document.querySelectorAll('.cart-count');
  
  cartCounts.forEach(counter => {
    const count = cart.length;
    counter.textContent = count;
    counter.dataset.count = count; // Sync with data attribute
    
    // Toggle visibility and background
    if (count > 0) {
      counter.classList.remove('cart-count-hidden');
      counter.classList.add('bg-yellow-400');
    } else {
      counter.classList.add('cart-count-hidden');
      counter.classList.remove('bg-yellow-400');
    }
  });
}

// Navigation function
function navigateToDetails(report) {
  // You can use either URL parameters or localStorage to pass data
  const params = new URLSearchParams();
  params.set('id', report.id);
  params.set('title', encodeURIComponent(report.title));
  params.set('price', report.price);
  params.set('category', encodeURIComponent(report.category));
  params.set('thumbnail', encodeURIComponent(report.thumbnail));
  params.set('downloads', report.download_count || 0);
  
  // Navigate to details page
  window.location.href = `report-details.php?${params.toString()}`;
  
  // Alternative: Store in localStorage and navigate
  // localStorage.setItem('currentReport', JSON.stringify(report));
  // window.location.href = 'report-details.html';
}

function renderStars(rating) {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  const stars = [];

  for (let i = 0; i < fullStars; i++) {
    stars.push(`<svg class="lucide lucide-star h-4 w-4 fill-yellow-400 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`);
  }

  if (halfStar) {
    stars.push(`
      <div class="relative">
        <svg class="lucide lucide-star h-4 w-4 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        <div class="absolute inset-0 overflow-hidden w-1/2">
          <svg class="lucide lucide-star h-4 w-4 fill-yellow-400 text-yellow-400" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        </div>
      </div>
    `);
  }

  return stars.join('');
}

// Sync function
async function syncCartItemWithServer(item, action) {
  try {

    // First get user ID
    const user_id = await getCurrentUserId();
    if (!user_id) {
      throw new Error('User not authenticated');
    }

    const response = await fetch('fetch/downloads.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: user_id, // From auth session
        item_id: item.id,
        item_price: item.price,
        action: action
      })
    });
    
    if (!response.ok) throw new Error('Sync failed');
    
    const data = await response.json();
    if (!data.success) throw new Error(data.message || 'Sync failed');
    console.log(data);
  } catch (error) {
    console.error('Cart sync error:', error);
    // Queue for retry later
    queueFailedSync(item, action);
  }
}

async function getCurrentUserId() {
  try {
    const response = await fetch('fetch/auth.php');
     if (!response.ok) throw new Error('Failed to get user ID');
      const data = await response.json();
      return data.user_id;

  } catch (error) {
    console.error('Error getting user ID:', error);
    return null; // Handle this case in your UI
  }
}

// Function to queue failed syncs
function queueFailedSync(item, action) {
  const failedSyncs = JSON.parse(localStorage.getItem('failedSyncs')) || [];
  failedSyncs.push({ item, action, timestamp: Date.now() });
  localStorage.setItem('failedSyncs', JSON.stringify(failedSyncs));
}

// Call the function when the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  fetchReports();
});